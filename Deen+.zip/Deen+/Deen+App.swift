//
//  MuslimPrayerApp.swift
//  MuslimPrayer
//
//  Created by Reyyan Bereka on 7/16/26.
//

import SwiftUI

@main
struct Deen_App: App {
    
    @StateObject private var locationManager = LocationManager()
    @StateObject private var qiblaManager = QiblaManager()
    @StateObject private var prayerManager = PrayerManager()
    
    init() {
        NotificationManager.shared.requestPermission()
    }
    
    var body: some Scene {
        
        WindowGroup {
            ContentView()
                .environmentObject(prayerManager)
                .environmentObject(locationManager)
                .environmentObject(qiblaManager)
        }
    }
}
