//
//  PrayerResponse.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/21/26.
//
import Foundation

struct PrayerResponse: Codable {
    let data: PrayerData
}

struct PrayerData: Codable {
    let timings: PrayerTiming
}

struct PrayerTiming: Codable {
    let Fajr: String
    let Sunrise: String
    let Dhuhr: String
    let Asr: String
    let Maghrib: String
    let Isha: String
}
