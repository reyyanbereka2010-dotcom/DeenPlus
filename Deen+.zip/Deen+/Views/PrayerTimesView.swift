import SwiftUI

struct PrayerTimesView: View {

    @EnvironmentObject var prayerManager: PrayerManager

    var body: some View {

        NavigationStack {

            List {

                if prayerManager.isLoading {

                    ProgressView("Loading prayer times...")
                        .frame(maxWidth: .infinity)

                } else {

                    PrayerRow(
                        name: "Fajr",
                        time: prayerManager.prayerTimes.fajr,
                        icon: "sunrise.fill"
                    )

                    PrayerRow(
                        name: "Sunrise",
                        time: prayerManager.prayerTimes.sunrise,
                        icon: "sun.min.fill"
                    )

                    PrayerRow(
                        name: "Dhuhr",
                        time: prayerManager.prayerTimes.dhuhr,
                        icon: "sun.max.fill"
                    )

                    PrayerRow(
                        name: "Asr",
                        time: prayerManager.prayerTimes.asr,
                        icon: "sun.max"
                    )

                    PrayerRow(
                        name: "Maghrib",
                        time: prayerManager.prayerTimes.maghrib,
                        icon: "sunset.fill"
                    )

                    PrayerRow(
                        name: "Isha",
                        time: prayerManager.prayerTimes.isha,
                        icon: "moon.stars.fill"
                    )
                }
            }
            
            .navigationTitle("Prayer Times")

        }
    }
}

#Preview {
    PrayerTimesView()
        .environmentObject(PrayerManager())
}
struct PrayerRow: View {

    let name: String
    let time: String
    let icon: String

    var body: some View {

        HStack {

            Image(systemName: icon)
                .frame(width: 30)

            Text(name)
                .font(.headline)

            Spacer()

            Text(convertTime(time))
                .foregroundStyle(.secondary)

        }
        .padding(.vertical, 8)
    }


    func convertTime(_ time: String) -> String {

        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"

        guard let date = formatter.date(from: time) else {
            return time
        }

        formatter.dateFormat = "h:mm a"

        return formatter.string(from: date)
    }
}
