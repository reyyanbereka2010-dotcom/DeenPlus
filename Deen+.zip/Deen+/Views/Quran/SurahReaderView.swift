import SwiftUI

struct SurahReaderView: View {

    let surah: Int
    let surahName: String

    @StateObject private var quranManager = QuranManager()

    @State private var arabicSize: CGFloat = 40
    @State private var showTranslation = true


    var body: some View {

        NavigationStack {

            ScrollViewReader { proxy in

                ScrollView {

                    VStack(spacing: 20) {


                        if let first = quranManager.verses.first {

                            SurahHeader(
                                surahName: surahName,
                                arabicName: getArabicName(),
                                versesCount: quranManager.verses.count,
                                revelationPlace: ""
                            )

                        }


                        ForEach(quranManager.verses) { verse in


                            VerseRow(
                                verse: verse,
                                arabicSize: arabicSize,
                                showTranslation: showTranslation
                            )

                            .id(verse.id)

                        }


                    }

                    .padding(.top)

                }


            }

            .navigationTitle(surahName)

            .navigationBarTitleDisplayMode(
                .inline
            )


            .safeAreaInset(edge: .bottom) {


                QuranToolbar(
                    arabicSize: $arabicSize,
                    showTranslation: $showTranslation
                )

            }


            .task {

                await quranManager.fetchVerses(
                    for: surah
                )

            }

        }

    }



    func getArabicName() -> String {

        let names: [Int:String] = [

            1:"الفاتحة",
            2:"البقرة",
            3:"آل عمران",
            4:"النساء",
            5:"المائدة",
            6:"الأنعام",
            7:"الأعراف",
            8:"الأنفال",
            9:"التوبة",
            10:"يونس"

        ]


        return names[surah] ?? ""

    }

}
