import SwiftUI

struct QuranView: View {

    @StateObject private var surahManager = SurahManager()

    @State private var searchText = ""

    
    var filteredSurahs: [Surah] {

        if searchText.isEmpty {
            return surahManager.surahs
        }

        return surahManager.surahs.filter { surah in

            surah.name.localizedCaseInsensitiveContains(searchText)
            ||
            surah.arabicName.contains(searchText)

        }

    }


    var body: some View {

        NavigationStack {

            Group {

                if surahManager.isLoading {

                    ProgressView("Loading Quran...")

                } else {

                    ScrollView {

                        LazyVStack(spacing: 12) {

                            ForEach(filteredSurahs) { surah in

                                NavigationLink {

                                    SurahReaderView(
                                        surah: surah.id,
                                        surahName: surah.name
                                    )

                                } label: {

                                    SurahRow(surah: surah)

                                }

                            }

                        }
                        .padding(.vertical)

                    }

                }

            }
            .navigationTitle("Quran")
            .searchable(
                text: $searchText,
                prompt: "Search Surah"
            )

        }
        .task {

            await surahManager.fetchSurahs()

        }

    }

}



struct SurahRow: View {

    let surah: Surah


    var body: some View {

        HStack(spacing: 18) {


            ZStack {

                Circle()
                    .fill(
                        Color.green.opacity(0.15)
                    )
                    .frame(
                        width: 46,
                        height: 46
                    )


                Text("\(surah.id)")
                    .fontWeight(.semibold)
                    .foregroundStyle(.green)

            }



            VStack(alignment: .leading, spacing: 6) {


                Text(surah.name)

                    .font(.headline)



                Text(surah.arabicName)

                    .font(
                        .custom(
                            "KFGQPC Uthmanic Script HAFS Regular",
                            size: 25
                        )
                    )

            }



            Spacer()



            VStack(alignment: .trailing, spacing: 5) {


                Text("\(surah.versesCount)")
                    .font(.caption)
                    .foregroundStyle(.secondary)



                Text(surah.revelationPlace)

                    .font(.caption2)
                    .foregroundStyle(.secondary)

            }


        }

        .padding()

        .background(

            RoundedRectangle(
                cornerRadius: 18
            )
            .fill(
                Color(.systemBackground)
            )

        )

        .overlay(

            RoundedRectangle(
                cornerRadius: 18
            )
            .stroke(
                Color.gray.opacity(0.15)
            )

        )

        .padding(.horizontal)

    }

}
