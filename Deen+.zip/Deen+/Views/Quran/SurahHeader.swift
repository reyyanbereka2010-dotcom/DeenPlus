//
//  SurahHeader.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/22/26.
//

import SwiftUI

struct SurahHeader: View {

    let surahName: String
    let arabicName: String
    let versesCount: Int
    let revelationPlace: String


    var body: some View {

        VStack(spacing: 18) {


            Text(arabicName)

                .font(
                    .custom(
                        "KFGQPC Uthmanic Script HAFS Regular",
                        size: 42
                    )
                )

                .multilineTextAlignment(.center)



            Text(surahName)

                .font(.title2)
                .fontWeight(.semibold)



            Text(
                "\(revelationPlace) • \(versesCount) Verses"
            )

            .font(.caption)

            .foregroundStyle(.secondary)



            Divider()
                .padding(.top, 10)



            // Bismillah

            if surahName != "At-Tawbah" {

                Text(
                    "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"
                )

                .font(
                    .custom(
                        "KFGQPC Uthmanic Script HAFS Regular",
                        size: 36
                    )
                )

                .multilineTextAlignment(.center)

                .environment(
                    \.layoutDirection,
                     .rightToLeft
                )

                .padding(.top, 10)

            }


            Divider()

        }

        .padding()

    }

}
