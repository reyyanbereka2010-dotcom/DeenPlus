//
//  QuranToolbar.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/22/26.
//
import SwiftUI

struct QuranToolbar: View {

    @Binding var arabicSize: CGFloat
    @Binding var showTranslation: Bool


    var body: some View {

        HStack(spacing: 28) {


            // A-
            Button {

                if arabicSize > 28 {
                    arabicSize -= 2
                }

            } label: {

                Text("A−")
                    .font(.headline)

            }



            // A+
            Button {

                if arabicSize < 60 {
                    arabicSize += 2
                }

            } label: {

                Text("A+")
                    .font(.headline)

            }



            // Translation toggle
            Button {

                showTranslation.toggle()

            } label: {

                Image(
                    systemName:
                        showTranslation
                        ? "globe"
                        : "eye.slash"
                )

            }



            // Audio placeholder
            Button {

            } label: {

                Image(systemName: "headphones")

            }



            // Search placeholder
            Button {

            } label: {

                Image(systemName: "magnifyingglass")

            }

        }

        .font(.title3)

        .padding(.horizontal, 20)
        .padding(.vertical, 14)

        .background(
            .ultraThinMaterial
        )

    }

}
