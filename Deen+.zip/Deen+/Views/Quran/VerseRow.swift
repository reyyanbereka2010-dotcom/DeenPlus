//
//  VerseRow.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/22/26.
//

import SwiftUI

struct VerseRow: View {

    let verse: QuranVerse
    let arabicSize: CGFloat
    let showTranslation: Bool


    var body: some View {

        VStack(spacing: 24) {


            // Arabic text

            Text(verse.arabic)

                .font(
                    .custom(
                        "KFGQPC Uthmanic Script HAFS Regular",
                        size: arabicSize
                    )
                )

                .multilineTextAlignment(.center)

                .lineSpacing(18)

                .environment(
                    \.layoutDirection,
                    .rightToLeft
                )

                .padding(.horizontal)



            // Translation

            Text(verse.translation)

                .font(.body)

                .multilineTextAlignment(.leading)

                .foregroundStyle(.secondary)

                .padding(.horizontal)



            // Actions

            HStack(spacing: 28) {


                Button {

                    // Audio will go here later

                } label: {

                    Image(
                        systemName: "play.circle"
                    )

                }



                Button {

                    // Bookmark will go here later

                } label: {

                    Image(
                        systemName: "bookmark"
                    )

                }



                Spacer()



                Text(
                    verse.verseKey
                )

                .font(.caption)

                .foregroundStyle(.secondary)


            }

            .padding(.horizontal)



            Divider()

        }

        .padding(.vertical, 20)

    }

}
