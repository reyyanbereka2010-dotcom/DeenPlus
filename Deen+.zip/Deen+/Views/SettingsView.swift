//
//  SettingsView.swift
//  MuslimPrayer
//
//  Created by Reyyan Bereka on 7/16/26.
//

import SwiftUI

struct SettingsView: View {
    
    @AppStorage("notificationsEnabled") var notificationsEnabled = true
    @AppStorage("calculationMethod") var calculationMethod = "Muslim World League"
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section("Prayer Notifications") {
                    
                    Toggle(
                        "Enable Notifications",
                        isOn: $notificationsEnabled
                    )
                    .onChange(of: notificationsEnabled) { enabled in
                        
                        if enabled {
                            NotificationManager.shared.requestPermission()
                        } else {
                            NotificationManager.shared.cancelPrayerNotifications()
                        }
                    }
                }
                
                
                Section("Prayer Calculation") {
                    
                    Picker(
                        "Method",
                        selection: $calculationMethod
                    ) {
                        
                        Text("Muslim World League")
                            .tag("Muslim World League")
                        
                        Text("ISNA")
                            .tag("ISNA")
                        
                        Text("Egyptian")
                            .tag("Egyptian")
                        
                        Text("Umm Al-Qura")
                            .tag("Umm Al-Qura")
                    }
                }
                
                
                Section {
                    
                    Text("Deen+")
                        .font(.headline)
                    
                    Text("Your daily prayer companion")
                        .foregroundStyle(.secondary)
                    
                } header: {
                    Text("About")
                } footer: {
                    Text("In memory of Bereka")
                        .font(.subheadline)
                        .foregroundStyle(.gray)
                }
                
            }
            .navigationTitle("Settings")
        }
    }
}
    

#Preview {
        SettingsView()
    }
