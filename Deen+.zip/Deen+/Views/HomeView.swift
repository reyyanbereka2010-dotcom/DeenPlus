//
//  HomeView.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/16/26.
//

import SwiftUI

struct HomeView: View {
    @State private var hideTabBar = false
    @Binding var selectedTab: Int
    @EnvironmentObject var prayerManager: PrayerManager
    @StateObject private var locationManager = LocationManager()
    
    var nextPrayer: (name: String, time: String) {
        
        let prayers = [
            ("Fajr", prayerManager.prayerTimes.fajr),
            ("Dhuhr", prayerManager.prayerTimes.dhuhr),
            ("Asr", prayerManager.prayerTimes.asr),
            ("Maghrib", prayerManager.prayerTimes.maghrib),
            ("Isha", prayerManager.prayerTimes.isha)
        ]
        
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        
        let calendar = Calendar.current
        let now = Date()
        
        for prayer in prayers {
            
            guard let time = formatter.date(from: prayer.1) else {
                continue
            }
            
            var components = calendar.dateComponents([.hour, .minute], from: time)
            
            components.year = calendar.component(.year, from: now)
            components.month = calendar.component(.month, from: now)
            components.day = calendar.component(.day, from: now)
            
            if let prayerDate = calendar.date(from: components),
               prayerDate > now {
                
                return prayer
            }
        }
        
        // If all prayers passed, tomorrow's Fajr
        return prayers[0]
    }
    var skyColors: [Color] {
        
        switch nextPrayer.name {
            
        case "Fajr":
            return [
                Color(red: 0.15, green: 0.25, blue: 0.55),
                Color(red: 0.95, green: 0.55, blue: 0.35),
                .yellow
            ]
            
        case "Dhuhr":
            return [
                .blue,
                Color(red: 0.3, green: 0.7, blue: 1.0),
                .white
            ]
            
        case "Asr":
            return [
                Color(red: 0.2, green: 0.5, blue: 0.9),
                .orange,
                .yellow
            ]
            
        case "Maghrib":
            return [
                Color(red: 0.8, green: 0.3, blue: 0.2),
                .purple,
                .blue
            ]
            
        case "Isha":
            return [
                Color(red: 0.02, green: 0.05, blue: 0.15),
                .indigo,
                .black
            ]
            
        default:
            return [.blue, .white]
        }
    }
    
    var formattedNextPrayerTime: String {
        
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        
        let displayFormatter = DateFormatter()
        displayFormatter.dateFormat = "h:mm a"
        
        if let date = formatter.date(from: nextPrayer.time) {
            return displayFormatter.string(from: date)
        }
        
        return nextPrayer.time
    }
    
    var prayerIcon: String {
        
        switch nextPrayer.name {
            
        case "Fajr":
            return "sunrise.fill"
            
        case "Dhuhr":
            return "sun.max.fill"
            
        case "Asr":
            return "sun.haze.fill"
            
        case "Maghrib":
            return "sunset.fill"
            
        case "Isha":
            return "moon.stars.fill"
            
        default:
            return "sun.max.fill"
        }
    }
    
    let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .full
        return formatter
    }()
    
    var body: some View {
        
        NavigationStack {
            
            ZStack {
                
                LinearGradient(
                    colors: skyColors,
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                
                ScrollView {
                    
                    ScrollDetector(hideTabBar: $hideTabBar)
                        .frame(height: 0)
                    
                    VStack(spacing: 25) {
                        
                        VStack(spacing: 25) {
                            
                            Text("Assalamu Alaikum,")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                                .foregroundStyle(.white)
                            
                            Text(
                                locationManager.city == "Unknown"
                                ? "📍 Finding location..."
                                : "📍 \(locationManager.city)"
                            )
                            .foregroundStyle(.white)
                            
                            Text(dateFormatter.string(from: Date()))
                                .foregroundStyle(.white.opacity(0.9))
                            
                            
                            Image(systemName: prayerIcon)
                                .font(.system(size: 90))
                                .foregroundStyle(.white)
                            
                            
                            Text("Next Prayer")
                                .font(.headline)
                                .foregroundStyle(.white.opacity(0.9))
                            
                            Text(nextPrayer.name)
                                .font(.system(size: 40, weight: .bold))
                                .foregroundStyle(.white)
                            
                            Text(formattedNextPrayerTime)
                                .font(.title2)
                                .foregroundStyle(.white)
                            
                            
                            Button {
                                
                                selectedTab = 1
                                
                            } label: {
                                
                                
                                Text("View Prayer Times")
                                    .font(.headline)
                                    .padding(.horizontal, 35)
                                    .padding(.vertical, 14)
                                    .background(.white)
                                    .foregroundStyle(.black)
                                    .clipShape(Capsule())
                                    .shadow(radius: 8)
                                
                            }
                            
                            Spacer()
                            VStack(spacing: 0) {
                                
                                HStack {
                                    
                                    Button {
                                        selectedTab = 2
                                    } label: {
                                        
                                        VStack(spacing: 6) {
                                            
                                            Image(systemName: "location.north.fill")
                                                .font(.title2)
                                            
                                            Text("Qibla")
                                                .font(.headline)
                                            
                                            Text("Find direction")
                                                .font(.caption)
                                                .opacity(0.8)
                                            
                                        }
                                        .frame(maxWidth: .infinity)
                                        
                                    }
                                    
                                    
                                    Divider()
                                        .frame(height: 50)
                                    
                                    
                                    Button {
                                        selectedTab = 3
                                    } label: {
                                        
                                        VStack(spacing: 6) {
                                            
                                            Image(systemName: "book.fill")
                                                .font(.title2)
                                            
                                            Text("Quran")
                                                .font(.headline)
                                            
                                            Text("Read Quran")
                                                .font(.caption)
                                                .opacity(0.8)
                                            
                                        }
                                        .frame(maxWidth: .infinity)
                                        
                                    }
                                    
                                }
                                .padding()
                            }
                            .background(.white.opacity(0.2))
                            .clipShape(RoundedRectangle(cornerRadius: 25))
                            .foregroundStyle(.white)
                            .padding(.horizontal)
                        }
                    }
                    .onAppear {
                        locationManager.requestLocation()
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            prayerManager.fetchPrayerTimes(
                                latitude: locationManager.latitude,
                                longitude: locationManager.longitude
                            )
                        }
                    }
                }
            }
            
            
        }
        
        
        
    }
    
}
#Preview {
        HomeView(selectedTab: .constant(0))
            .environmentObject(PrayerManager())
    }
