//
//  QiblaView.swift
//  MuslimPrayer
//
//  Created by Reyyan Bereka on 7/16/26.
//

import SwiftUI

struct QiblaView: View {
    
    @State private var qiblaViewActive = false
    @State private var hasVibrated = false
    @EnvironmentObject var qiblaManager: QiblaManager
    @EnvironmentObject var locationManager: LocationManager

    var body: some View {

        VStack(spacing: 30) {

            Text("Qibla Finder")
                .font(.largeTitle)
                .bold()


            Image(systemName: "location.north.fill")
                .font(.system(size: 120))
                .rotationEffect(.degrees(qiblaManager.arrowRotation))
                .foregroundStyle(qiblaManager.isFacingQibla ? .green : .primary)
                


            Text(
                "Qibla: \(Int(qiblaManager.qiblaDirection))°"
            )
            .font(.title)
            
            if qiblaManager.isFacingQibla {

                Text("✓ Facing Qibla")
                    .font(.headline)
                    .foregroundStyle(.green)

            } else {

                Text("Turn until the arrow turns green")
                    .foregroundStyle(.secondary)

            }

            if locationManager.latitude != 0 {

                Text(locationManager.city)
                    .font(.headline)


                Text("Location detected")
                    .foregroundStyle(.green)


            } else {

                ProgressView("Finding location...")
                    .onAppear {
                        locationManager.requestLocation()
                    }
            }

        }
        .onChange(of: qiblaManager.isFacingQibla) { facing in
            
            if facing && qiblaViewActive && !hasVibrated {
                
                let generator = UIImpactFeedbackGenerator(style: .medium)
                generator.prepare()
                generator.impactOccurred()
                
                hasVibrated = true
            }
            
            if !facing {
                hasVibrated = false
            }
        }
        .onChange(
            of: locationManager.latitude
        ) {

            qiblaManager.calculateQibla(
                latitude: locationManager.latitude,
                longitude: locationManager.longitude
            )
        }
        .onAppear {
            qiblaViewActive = true
        }

        .onDisappear {
            qiblaViewActive = false
            hasVibrated = false
        }
    }

}
