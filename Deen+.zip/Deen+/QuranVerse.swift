import Foundation


struct QuranVerse: Identifiable, Codable {

    let id: Int
    let verseKey: String
    let arabic: String
    let translation: String

}



struct QuranResponse: Codable {

    let verses: [QuranAPIVerse]

}



struct QuranAPIVerse: Codable {

    let id: Int

    let verseKey: String

    let textUthmani: String?

    let translations: [Translation]?


    enum CodingKeys: String, CodingKey {

        case id

        case verseKey = "verse_key"

        case textUthmani = "text_uthmani"

        case translations

    }

}



struct Translation: Codable {

    let text: String

}
