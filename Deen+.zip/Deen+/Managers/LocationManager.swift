import Foundation
import CoreLocation
import Combine

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    
    private let manager = CLLocationManager()
    @Published var city = "Unknown"
    @Published var latitude: Double = 0
    @Published var longitude: Double = 0
    
    override init() {
        super.init()
        
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }
    
    func requestLocation() {
        if manager.authorizationStatus == .notDetermined {
            manager.requestWhenInUseAuthorization()
        } else {
            manager.requestLocation()
        }
    }
    
        
    func locationManager(_ manager: CLLocationManager,
            didUpdateLocations locations: [CLLocation]) {
            
            guard let location = locations.first else { return }
            
            latitude = location.coordinate.latitude
            longitude = location.coordinate.longitude
            
            let geocoder = CLGeocoder()
            
            geocoder.reverseGeocodeLocation(location) { placemarks, error in
                
                if let error = error {
                    print("Geocoding error:", error.localizedDescription)
                    return
                }
                
                guard let placemark = placemarks?.first else {
                    print("No placemark found")
                    return
                }
                
                DispatchQueue.main.async {
                    self.city =
                    placemark.locality ??
                    placemark.subAdministrativeArea ??
                    placemark.administrativeArea ??
                    "Unknown"
                }
            }
        }
        
        func locationManager(_ manager: CLLocationManager,
                             didFailWithError error: Error) {
            print("Location error:", error.localizedDescription)
        }
        
        func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
            switch manager.authorizationStatus {
            case .authorizedWhenInUse, .authorizedAlways:
                manager.requestLocation()
            default:
                break
            }
        }
    }
