//
//  PrayerManager.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/19/26.
//
import Foundation
import Combine

class PrayerManager: ObservableObject {
    
    @Published var isLoading = true
    @Published var prayerTimes = PrayerTimes(
        fajr: "--:--",
        sunrise: "--:--",
        dhuhr: "--:--",
        asr: "--:--",
        maghrib: "--:--",
        isha: "--:--"
    )

    func fetchPrayerTimes(latitude: Double, longitude: Double) {

        let urlString = "https://api.aladhan.com/v1/timings?latitude=\(latitude)&longitude=\(longitude)&method=2"

        guard let url = URL(string: urlString) else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in

            guard let data = data else {
                DispatchQueue.main.async {
                    self.isLoading = false
                }
                return
            }

            do {
                let decoded = try JSONDecoder().decode(PrayerResponse.self, from: data)

                DispatchQueue.main.async {
                    self.prayerTimes = PrayerTimes(
                        fajr: decoded.data.timings.Fajr,
                        sunrise: decoded.data.timings.Sunrise,
                        dhuhr: decoded.data.timings.Dhuhr,
                        asr: decoded.data.timings.Asr,
                        maghrib: decoded.data.timings.Maghrib,
                        isha: decoded.data.timings.Isha
                    )
                    
                    NotificationManager.shared.schedulePrayerNotifications(
                        prayerTimes: self.prayerTimes
                    )
                    
                    self.isLoading = false
                }

            } catch {
                print(error)

                DispatchQueue.main.async {
                    self.isLoading = false
                }
            }

        }.resume()
    }
}
