//
//  NotificationManager.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/22/26.
//

import Foundation
import UserNotifications

class NotificationManager {
    private func prayerMessage(for prayer: String) -> String {

        switch prayer {

        case "Fajr":
            return "Start your day with remembrance of Allah."

        case "Dhuhr":
            return "Take a moment to reconnect with Allah."

        case "Asr":
            return "Pause and make time for Salah."

        case "Maghrib":
            return "The sun has set. It is time for prayer."

        case "Isha":
            return "End your day with prayer and gratitude."

        default:
            return "It is time for Salah."
        }
    }
    
    func cancelPrayerNotifications() {

        UNUserNotificationCenter.current()
            .removeAllPendingNotificationRequests()

    }

    static let shared = NotificationManager()

    private init() {}

    
    func requestPermission() {

        UNUserNotificationCenter.current()
            .requestAuthorization(
                options: [.alert, .sound, .badge]
            ) { granted, error in

                if granted {
                    print("Notifications allowed")
                } else {
                    print("Notifications denied")
                }
            }
    }


    func schedulePrayerNotifications(
        prayerTimes: PrayerTimes
    ) {

        let prayers = [
            ("Fajr", prayerTimes.fajr),
            ("Dhuhr", prayerTimes.dhuhr),
            ("Asr", prayerTimes.asr),
            ("Maghrib", prayerTimes.maghrib),
            ("Isha", prayerTimes.isha)
        ]


        // Remove old notifications first
        UNUserNotificationCenter.current()
            .removeAllPendingNotificationRequests()


        for prayer in prayers {

            schedule(
                name: prayer.0,
                time: prayer.1
            )
        }
    }



    private func schedule(
        name: String,
        time: String
    ) {

        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"


        guard let date = formatter.date(from: time)
        else { return }


        let calendar = Calendar.current


        let components = calendar.dateComponents(
            [.hour, .minute],
            from: date
        )


        let content = UNMutableNotificationContent()

        content.title = "\(name) Prayer Time"
        content.body = prayerMessage(for: name)
        content.sound = UNNotificationSound(
            named: UNNotificationSoundName("adhan.caf")
        )



        let trigger = UNCalendarNotificationTrigger(
            dateMatching: components,
            repeats: true
        )


        let request = UNNotificationRequest(
            identifier: name,
            content: content,
            trigger: trigger
        )


        UNUserNotificationCenter.current()
            .add(request)
    }
}
