import Foundation
import Combine


@MainActor
class QuranManager: ObservableObject {

    @Published var verses: [QuranVerse] = []

    @Published var isLoading = false


    func fetchVerses(for surah: Int) async {

        isLoading = true


        let urlString =
        "https://api.quran.com/api/v4/verses/by_chapter/\(surah)?translations=131&fields=text_uthmani&per_page=300"


        guard let url = URL(string: urlString) else {
            isLoading = false
            return
        }


        do {

            let (data, _) =
            try await URLSession.shared.data(
                from: url
            )


            print(
                String(
                    data: data,
                    encoding: .utf8
                )
                ?? ""
            )


            let response =
            try JSONDecoder().decode(
                QuranResponse.self,
                from: data
            )


            self.verses =
            response.verses.map { verse in


                QuranVerse(

                    id: verse.id,

                    verseKey: verse.verseKey,

                    arabic:
                        verse.textUthmani
                        ?? "",

                    translation:
                        verse.translations?
                        .first?
                        .text
                        ?? ""

                )

            }


        } catch {

            print("Quran error:")
            print(error)

        }


        isLoading = false

    }

}



struct QuranResponse: Codable {

    let verses: [QuranAPIVerse]

}



struct QuranAPIVerse: Codable {

    let id: Int

    let verseKey: String

    let textUthmani: String?

    let translations: [Translation]?



    enum CodingKeys: String, CodingKey {

        case id

        case verseKey = "verse_key"

        case textUthmani = "text_uthmani"

        case translations

    }

}
