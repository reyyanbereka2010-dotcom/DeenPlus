//
//  PrayerTimes.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/19/26.
//
import Foundation

struct PrayerTimes {
    let fajr: String
    let sunrise: String
    let dhuhr: String
    let asr: String
    let maghrib: String
    let isha: String
}
