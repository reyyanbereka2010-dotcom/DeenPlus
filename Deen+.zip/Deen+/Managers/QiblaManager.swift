//
//  QiblaManager.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/21/26.
//

import Foundation
import CoreLocation
import Combine

class QiblaManager: NSObject, ObservableObject {
    
    @Published var displayedRotation: Double = 0
    @Published var heading: Double = 0
    @Published var qiblaDirection: Double = 0

    private let locationManager = CLLocationManager()
    private let kaabaLatitude = 21.4225
    private let kaabaLongitude = 39.8262

    override init() {
        super.init()

        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()

        if CLLocationManager.headingAvailable() {
            locationManager.startUpdatingHeading()
        }
    }
    
    var arrowRotation: Double {

        var angle = qiblaDirection - heading

        while angle < -180 {
            angle += 360
        }

        while angle > 180 {
            angle -= 360
        }

        return angle
    }
    
    var isFacingQibla: Bool {
        abs(arrowRotation) <= 5
    }

    func calculateQibla(latitude: Double, longitude: Double) {

        let userLat = latitude * .pi / 180
        let userLon = longitude * .pi / 180

        let kaabaLat = kaabaLatitude * .pi / 180
        let kaabaLon = kaabaLongitude * .pi / 180


        let deltaLon = kaabaLon - userLon

        let y = sin(deltaLon) * cos(kaabaLat)

        let x = cos(userLat) * sin(kaabaLat)
            - sin(userLat) * cos(kaabaLat) * cos(deltaLon)


        let angle = atan2(y, x)

        let degrees = angle * 180 / .pi

        qiblaDirection = (degrees + 360)
            .truncatingRemainder(dividingBy: 360)
    }
}


extension QiblaManager: CLLocationManagerDelegate {

    func locationManager(
        _ manager: CLLocationManager,
        didUpdateHeading newHeading: CLHeading
    ) {

        DispatchQueue.main.async {

            self.heading = newHeading.trueHeading
        }
    }
}
