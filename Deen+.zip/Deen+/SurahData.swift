//
//  SurahData.swift
//  Deen+
//
//  Created by Reyyan Bereka on 7/22/26.
//

import Foundation
